#!/usr/bin/env python3
"""
PROFESSOR IS WATCHING - Signal Bot
Desktop App - No API - Pure Technical Analysis
Compatible: Python 3.8+ on Windows/Mac/Linux
"""
import tkinter as tk
import math, time, datetime, threading, json, random
from pathlib import Path

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "signals.json"

WIN_W = 420
WIN_H = 720

BG      = "#000000"
PANEL   = "#0a0000"
CARD    = "#0d0000"
RED     = "#ff0000"
RED2    = "#cc0000"
RED3    = "#880000"
RED4    = "#440000"
ORANGE  = "#ff4400"
GREEN   = "#00ff44"
GREEN2  = "#00cc33"
GREEN_B = "#001800"
WHITE   = "#ffffff"
GRAY    = "#aaaaaa"
MUTED   = "#555555"
DIM     = "#1a0000"

PAIRS = [
    "EUR/USD","GBP/USD","USD/JPY","USD/CHF",
    "AUD/USD","NZD/USD","USD/CAD","EUR/GBP",
    "EUR/JPY","GBP/JPY","USD/PKR","USD/BRL",
    "USD/MXN","EUR/CHF","USD/SGD","USD/COP",
    "USD/BRL (OTC)","EUR/USD (OTC)","GBP/USD (OTC)",
    "USD/JPY (OTC)","AUD/USD (OTC)","EUR/GBP (OTC)",
    "GBP/JPY (OTC)","USD/CAD (OTC)",
]

TIMEFRAMES = [
    "5s","10s","15s","30s","1m",
    "2m","3m","5m","10m","15m",
    "30m","1h","4h",
]

TF_W = {
    "5s":.55,"10s":.58,"15s":.60,"30s":.65,
    "1m":.70,"2m":.72,"3m":.75,"5m":.78,
    "10m":.80,"15m":.82,"30m":.85,"1h":.88,"4h":.92
}

BP = ["Bullish Engulfing","Hammer","Morning Star","Piercing Line",
      "Three White Soldiers","Inverted Hammer","Bullish Harami","Rising Three"]
DP = ["Bearish Engulfing","Shooting Star","Evening Star","Dark Cloud",
      "Three Black Crows","Hanging Man","Bearish Harami","Falling Three"]
NP = ["Doji","Spinning Top","Long-Legged Doji","Dragonfly Doji","Gravestone"]

history = []

# ─── Analysis Engine ──────────────────────────
def analyze(pair, tf):
    seed = int(time.time() * 1000) + sum(ord(c) for c in (pair + tf))
    def r(n=0):
        x = math.sin(float(seed + n * 9301)) * 10000.0
        return x - math.floor(x)

    rsi   = int(20 + r(0) * 60)
    macd  = (r(1) - 0.5) * 2.0
    bb    = r(2)
    stoch = int(10 + r(3) * 80)
    cci   = int(-150 + r(4) * 300)
    ma_x  = 1 if r(5) > 0.5 else -1
    vol   = round(0.6 + r(6) * 0.8, 2)
    adx   = int(15 + r(7) * 40)
    ao    = (r(8) - 0.5) * 4.0
    wpr   = int(-100 + r(9) * 100)

    bull = 0
    bear = 0

    if rsi < 35:     bull += 2
    elif rsi > 65:   bear += 2
    elif rsi < 45:   bull += 1
    elif rsi > 55:   bear += 1

    if macd > 0.2:   bull += 2
    elif macd < -0.2: bear += 2
    elif macd > 0:   bull += 1
    else:            bear += 1

    if bb < 0.2:     bull += 2
    elif bb > 0.8:   bear += 2

    if ma_x > 0:     bull += 2
    else:            bear += 2

    if stoch < 25:   bull += 1
    elif stoch > 75: bear += 1

    if cci < -100:   bull += 1
    elif cci > 100:  bear += 1

    if ao > 0.5:     bull += 1
    elif ao < -0.5:  bear += 1

    if wpr < -80:    bull += 1
    elif wpr > -20:  bear += 1

    tot = bull + bear
    bp_ = bull / tot if tot > 0 else 0.5
    tfw = TF_W.get(tf, 0.7)
    otc = 0.03 if "(OTC)" in pair else 0.0

    if bp_ > 0.53:
        sig  = "BUY"
        conf = min(95, int((50 + bp_ * 50) * tfw + otc * 100))
        pat  = BP[int(r(0) * len(BP))]
        trd  = "UPTREND"
    elif bp_ < 0.47:
        sig  = "SELL"
        conf = min(95, int((50 + (1 - bp_) * 50) * tfw + otc * 100))
        pat  = DP[int(r(1) * len(DP))]
        trd  = "DOWNTREND"
    else:
        sig  = "IDLE"
        conf = min(60, int(40 + r(2) * 15))
        pat  = NP[int(r(2) * len(NP))]
        trd  = "SIDEWAYS"

    if conf < 48:
        conf = 48

    return {
        "signal":     sig,
        "confidence": conf,
        "pattern":    pat,
        "trend":      trd,
        "rsi":        rsi,
        "pair":       pair,
        "timeframe":  tf,
        "timestamp":  datetime.datetime.now().isoformat(),
    }

def save_log(res):
    history.insert(0, res)
    if len(history) > 100:
        history.pop()
    try:
        with open(LOG_FILE, "w") as f:
            json.dump(history[:100], f, indent=2)
    except Exception:
        pass

# ─── Professor Face Canvas ────────────────────
class ProfFace(tk.Canvas):
    def __init__(self, parent, size=72):
        super().__init__(parent, width=size, height=size,
                         bg=BG, highlightthickness=0)
        s  = size
        cx = s // 2
        cy = s // 2
        r  = s // 2 - 2

        # Glow rings
        self.create_oval(cx-r,   cy-r,   cx+r,   cy+r,   outline=RED3, width=1)
        self.create_oval(cx-r+2, cy-r+2, cx+r-2, cy+r-2, outline=RED2, width=1)

        # Hood background
        self.create_oval(cx-r+3, cy-r+3, cx+r-3, cy+r-3,
                         fill="#1a0000", outline=RED2, width=2)

        # Hood triangle
        hw = r - 6
        self.create_polygon(cx, cy-hw,
                            cx-hw+4, cy+hw//2,
                            cx+hw-4, cy+hw//2,
                            fill="#330000", outline="")

        # Face
        fw = r - 14
        self.create_oval(cx-fw, cy-fw+2, cx+fw, cy+fw+8,
                         fill="#cc8844", outline="")

        # Eyes
        self.create_oval(cx-9, cy-5, cx-5, cy-1, fill="#111111", outline="")
        self.create_oval(cx+5, cy-5, cx+9, cy-1, fill="#111111", outline="")

        # Mustache
        self.create_arc(cx-10, cy+2, cx+10, cy+12,
                        start=0, extent=180,
                        fill="#553322", outline="")


# ─── Pair Dropdown ────────────────────────────
class PairDrop(tk.Frame):
    def __init__(self, parent, items, default=16):
        super().__init__(parent, bg=CARD,
                         highlightbackground=RED3,
                         highlightthickness=1)
        self.items  = items
        self.var    = tk.StringVar(value=items[default])
        self._popup = None

        self._btn = tk.Button(
            self,
            textvariable=self.var,
            font=("Courier", 11, "bold"),
            bg=CARD, fg=WHITE,
            relief="flat",
            anchor="w",
            padx=12,
            pady=9,
            cursor="hand2",
            activebackground=DIM,
            activeforeground=WHITE,
            command=self._toggle,
        )
        self._btn.pack(side="left", fill="x", expand=True)

        self._arr = tk.Label(self, text="  \u25bc  ",
                             font=("Courier", 10),
                             bg=CARD, fg=RED2,
                             cursor="hand2")
        self._arr.pack(side="right")
        self._arr.bind("<Button-1>", lambda e: self._toggle())

    def _toggle(self):
        if self._popup:
            self._close()
        else:
            self._open()

    def _open(self):
        self._arr.config(text="  \u25b2  ")
        pop = tk.Toplevel(self.winfo_toplevel())
        pop.overrideredirect(True)
        pop.attributes("-topmost", True)
        pop.configure(bg=RED2)
        self._popup = pop

        rx = self.winfo_rootx()
        ry = self.winfo_rooty() + self.winfo_height()
        w  = self.winfo_width()
        h  = min(len(self.items) * 32, 260)
        pop.geometry("%dx%d+%d+%d" % (w, h, rx, ry))

        cv = tk.Canvas(pop, bg=CARD, highlightthickness=0)
        sb = tk.Scrollbar(pop, orient="vertical", command=cv.yview,
                          bg=PANEL, troughcolor=BG)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        cv.pack(fill="both", expand=True)

        inner = tk.Frame(cv, bg=CARD)
        cv.create_window((0, 0), window=inner, anchor="nw")

        for opt in self.items:
            selected = (opt == self.var.get())
            row_bg = RED2 if selected else CARD
            row_fg = WHITE
            f = tk.Frame(inner, bg=row_bg)
            f.pack(fill="x")
            lbl = tk.Label(f, text=opt,
                           font=("Courier", 10),
                           bg=row_bg, fg=row_fg,
                           anchor="w", padx=12, pady=6,
                           cursor="hand2")
            lbl.pack(fill="x")
            sep = tk.Frame(inner, bg=RED4, height=1)
            sep.pack(fill="x")

            def on_click(e, o=opt):
                self._pick(o)
            f.bind("<Button-1>", on_click)
            lbl.bind("<Button-1>", on_click)

        inner.update_idletasks()
        cv.config(scrollregion=cv.bbox("all"))
        pop.bind("<FocusOut>", lambda e: self._close())
        pop.focus_set()

    def _close(self):
        self._arr.config(text="  \u25bc  ")
        if self._popup:
            try:
                self._popup.destroy()
            except Exception:
                pass
            self._popup = None

    def _pick(self, opt):
        self.var.set(opt)
        self._close()

    def get(self):
        return self.var.get()


# ─── Timeframe Grid ───────────────────────────
class TFGrid(tk.Frame):
    def __init__(self, parent, on_select):
        super().__init__(parent, bg=BG)
        self.on_select = on_select
        self.selected  = "1m"
        self.btns      = {}
        cols = 5
        for i, tf in enumerate(TIMEFRAMES):
            row_i = i // cols
            col_i = i % cols
            btn = tk.Button(
                self,
                text=tf,
                font=("Courier", 11, "bold"),
                relief="flat",
                cursor="hand2",
                padx=0,
                pady=7,
                command=lambda t=tf: self._pick(t),
            )
            btn.grid(row=row_i, column=col_i, padx=3, pady=3, sticky="nsew")
            self.btns[tf] = btn
            self.columnconfigure(col_i, weight=1)
        self._refresh()

    def _pick(self, tf):
        self.selected = tf
        self._refresh()
        self.on_select(tf)

    def _refresh(self):
        for tf, btn in self.btns.items():
            if tf == self.selected:
                btn.config(bg=RED2, fg=WHITE,
                           activebackground=RED,
                           activeforeground=WHITE)
            else:
                btn.config(bg=DIM, fg=GRAY,
                           activebackground=RED3,
                           activeforeground=WHITE)

    def get(self):
        return self.selected


# ─── Result Box ───────────────────────────────
class ResultBox(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG,
                         highlightbackground=RED3,
                         highlightthickness=1)
        self.config(height=110)
        self.pack_propagate(False)

        self._lbl = tk.Label(self, text="IDLE",
                             font=("Courier", 28, "bold"),
                             bg=BG, fg=MUTED)
        self._lbl.pack(expand=True)

        self._sub = tk.Label(self, text="",
                             font=("Courier", 9),
                             bg=BG, fg=MUTED)
        self._sub.pack()
        self._sub.pack_configure(pady=4)

        self._scanning = False

    def set_idle(self):
        self._scanning = False
        self.config(bg=BG, highlightbackground=RED3)
        self._lbl.config(text="IDLE", fg=MUTED, bg=BG,
                         font=("Courier", 28, "bold"))
        self._sub.config(text="", bg=BG)

    def set_scanning(self):
        self._scanning = True
        self.config(bg=BG, highlightbackground=RED2)
        self._lbl.config(text="SCANNING...", fg=RED, bg=BG,
                         font=("Courier", 16, "bold"))
        self._sub.config(text="Everything is planned..", fg=MUTED, bg=BG)
        self._blink()

    def _blink(self):
        if not self._scanning:
            return
        cur = self._lbl.cget("fg")
        nxt = RED if cur == BG else BG
        try:
            self._lbl.config(fg=nxt)
        except Exception:
            return
        self.after(500, self._blink)

    def show_result(self, res):
        self._scanning = False
        sig  = res["signal"]
        conf = res["confidence"]
        tf   = res["timeframe"]
        pat  = res["pattern"]

        if sig == "BUY":
            self.config(bg=GREEN_B, highlightbackground=GREEN2)
            self._lbl.config(text="BUY", fg=GREEN, bg=GREEN_B,
                             font=("Courier", 40, "bold"))
            self._sub.config(text="%s  |  %d%%  |  %s" % (pat, conf, tf),
                             fg=GREEN2, bg=GREEN_B)
        elif sig == "SELL":
            self.config(bg="#1a0000", highlightbackground=RED2)
            self._lbl.config(text="SELL", fg=RED, bg="#1a0000",
                             font=("Courier", 40, "bold"))
            self._sub.config(text="%s  |  %d%%  |  %s" % (pat, conf, tf),
                             fg=RED2, bg="#1a0000")
        else:
            self.config(bg=BG, highlightbackground=MUTED)
            self._lbl.config(text="IDLE", fg=MUTED, bg=BG,
                             font=("Courier", 28, "bold"))
            self._sub.config(text="%s  |  %d%%  |  %s" % (pat, conf, tf),
                             fg=MUTED, bg=BG)


# ─── History Panel ────────────────────────────
class HistPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=PANEL,
                         highlightbackground=RED3,
                         highlightthickness=1)
        self._empty_lbl = None
        self._build()

    def _build(self):
        header = tk.Frame(self, bg=PANEL)
        header.pack(fill="x")
        tk.Label(header, text="SIGNAL HISTORY",
                 font=("Courier", 8),
                 bg=PANEL, fg=MUTED).pack(anchor="w", padx=8, pady=6)
        tk.Frame(self, bg=RED3, height=1).pack(fill="x")

        self._canvas = tk.Canvas(self, bg=PANEL,
                                 height=120,
                                 highlightthickness=0)
        self._sb = tk.Scrollbar(self, orient="vertical",
                                command=self._canvas.yview,
                                bg=PANEL, troughcolor=BG)
        self._canvas.configure(yscrollcommand=self._sb.set)
        self._sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._inner = tk.Frame(self._canvas, bg=PANEL)
        self._cwin  = self._canvas.create_window(
            (0, 0), window=self._inner, anchor="nw")

        self._inner.bind("<Configure>", self._on_inner_config)
        self._canvas.bind("<Configure>", self._on_canvas_config)

        self._empty_lbl = tk.Label(
            self._inner, text="No signals yet",
            font=("Courier", 9),
            bg=PANEL, fg=MUTED)
        self._empty_lbl.pack(pady=14)

    def _on_inner_config(self, event):
        self._canvas.config(scrollregion=self._canvas.bbox("all"))

    def _on_canvas_config(self, event):
        self._canvas.itemconfig(self._cwin, width=event.width)

    def add(self, res):
        if self._empty_lbl is not None:
            self._empty_lbl.destroy()
            self._empty_lbl = None

        sig  = res["signal"]
        pair = res["pair"]
        tf   = res["timeframe"]
        conf = res["confidence"]
        try:
            ts = datetime.datetime.fromisoformat(
                res["timestamp"]).strftime("%H:%M:%S")
        except Exception:
            ts = "—"

        if sig == "BUY":
            fc  = GREEN
            ico = "\u25b2 BUY "
        elif sig == "SELL":
            fc  = RED
            ico = "\u25bc SELL"
        else:
            fc  = MUTED
            ico = "\u25c6 IDLE"

        row = tk.Frame(self._inner, bg=CARD)
        row.pack(fill="x", pady=1)

        tk.Label(row, text=ico,
                 font=("Courier", 10, "bold"),
                 bg=CARD, fg=fc,
                 width=7, anchor="w").pack(side="left")
        tk.Label(row, text=pair,
                 font=("Courier", 9),
                 bg=CARD, fg=WHITE,
                 width=16, anchor="w").pack(side="left")
        tk.Label(row, text=tf,
                 font=("Courier", 9),
                 bg=CARD, fg=MUTED,
                 width=5).pack(side="left")
        tk.Label(row, text="%d%%" % conf,
                 font=("Courier", 9, "bold"),
                 bg=CARD, fg=fc).pack(side="right")
        tk.Label(row, text=ts,
                 font=("Courier", 8),
                 bg=CARD, fg=MUTED).pack(side="right", padx=6)

        self._canvas.yview_moveto(0)


# ─── Main Application ─────────────────────────
class App:
    def __init__(self, root):
        self.root   = root
        self._busy  = False
        self._tf    = "1m"

        root.title("Professor Is Watching")
        root.geometry("%dx%d" % (WIN_W, WIN_H))
        root.resizable(False, False)
        root.configure(bg=BG)

        self._build()

    def _build(self):
        # Outer red border
        outer = tk.Frame(self.root, bg=BG,
                         highlightbackground=RED,
                         highlightthickness=2)
        outer.pack(fill="both", expand=True, padx=4, pady=4)

        # Top bar
        topbar = tk.Frame(outer, bg=BG)
        topbar.pack(fill="x", padx=12, pady=8)

        tk.Label(topbar, text="AGENT: ",
                 font=("Courier", 9, "bold"),
                 bg=BG, fg=WHITE).pack(side="left")
        tk.Label(topbar, text="professor@gmail.com",
                 font=("Courier", 9, "bold"),
                 bg=BG, fg=ORANGE).pack(side="left")
        tk.Label(topbar, text="LOGOUT",
                 font=("Courier", 9, "bold"),
                 bg=BG, fg=GRAY,
                 cursor="hand2").pack(side="right")

        # Professor face
        ProfFace(outer, size=72).pack(pady=8)

        # Glowing title
        self._title = tk.Label(outer,
                               text="PROFESSOR IS WATCHING",
                               font=("Courier", 15, "bold"),
                               bg=BG, fg=RED)
        self._title.pack(pady=4)
        self._glow_idx = 0
        self._glow()

        # Content area
        content = tk.Frame(outer, bg=BG)
        content.pack(fill="x", padx=16, pady=8)

        # Target asset label
        tk.Label(content, text="TARGET ASSET",
                 font=("Courier", 10, "bold"),
                 bg=BG, fg=RED).pack(anchor="w", pady=4)

        # Pair dropdown
        self._dd = PairDrop(content, PAIRS, default=16)
        self._dd.pack(fill="x", pady=4)

        # Timeframe label
        tk.Label(content, text="TIMEFRAME",
                 font=("Courier", 10, "bold"),
                 bg=BG, fg=RED).pack(anchor="w", pady=6)

        # TF grid
        self._tf_grid = TFGrid(content, self._on_tf)
        self._tf_grid.pack(fill="x", pady=4)

        # CHECK PROFESSOR'S PLAN button
        self._btn = tk.Button(
            content,
            text="CHECK PROFESSOR'S PLAN",
            command=self._click,
            bg=RED2, fg=WHITE,
            font=("Courier", 12, "bold"),
            relief="flat",
            cursor="hand2",
            pady=11,
            activebackground=RED,
            activeforeground=WHITE,
        )
        self._btn.pack(fill="x", pady=8)

        # Result box
        self._result = ResultBox(content)
        self._result.pack(fill="x", pady=4)

        # History
        self._hist = HistPanel(content)
        self._hist.pack(fill="x", pady=4)

        # Footer
        tk.Label(outer,
                 text="Simulation Mode  -  Educational Use Only",
                 font=("Courier", 7),
                 bg=BG, fg=MUTED).pack(pady=6)

    def _glow(self):
        colors = [RED, "#ff2200", "#ff4400", "#ff2200", RED, RED2, RED2]
        try:
            self._title.config(fg=colors[self._glow_idx % len(colors)])
        except Exception:
            return
        self._glow_idx += 1
        self.root.after(220, self._glow)

    def _on_tf(self, tf):
        self._tf = tf

    def _click(self):
        if self._busy:
            return
        self._busy = True
        self._btn.config(
            state="disabled",
            text="EVERYTHING IS PLANNED..",
            bg=RED3)
        self._result.set_scanning()
        threading.Thread(target=self._work, daemon=True).start()

    def _work(self):
        time.sleep(0.8 + random.random() * 0.6)
        res = analyze(self._dd.get(), self._tf)
        save_log(res)
        self.root.after(0, lambda r=res: self._done(r))

    def _done(self, res):
        self._result.show_result(res)
        self._hist.add(res)
        self._btn.config(
            state="normal",
            text="CHECK PROFESSOR'S PLAN",
            bg=RED2)
        self._busy = False


# ─── Entry ────────────────────────────────────
def main():
    root = tk.Tk()
    app  = App(root)
    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    x  = (sw - WIN_W) // 2
    y  = (sh - WIN_H) // 2
    root.geometry("%dx%d+%d+%d" % (WIN_W, WIN_H, x, y))
    root.mainloop()

if __name__ == "__main__":
    main()
