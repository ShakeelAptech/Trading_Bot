@echo off
title Professor Is Watching - Signal Bot
color 04
echo.
echo  ================================
echo   PROFESSOR IS WATCHING
echo   Signal Bot - No API Needed
echo  ================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python not installed!
    echo  Download: https://python.org
    pause & exit
)
python main.py
if errorlevel 1 ( echo. & echo Error! See above. & pause )
